@extends('master')
@section('content')
<div class="custom-product">
    <div class="col-sm-10">
    <h3>Total Bill</h3>
        <table class="table table-striped table-bordered table-hover">
        <tbody>
        <tr>
            <td>Amount</td>
            <td>$ {{ $total}}</td>
        </tr>
        <tr>
            <td>GST</td>
            <td>$ 0</td>
        </tr>
        <tr>
            <td>Delivery</td>
            <td>$ 50</td>
        </tr>
        <tr>
            <td>Total Amount</td>
            <td>$ {{ $total + 50 }}</td>
        </tr>
        </tbody>
        </table>
        <div>
            <form action="/placeorder" method="post">
            @csrf
                <div class="form-group">
                    <textarea name="address" class="form-control" placeholder="Enter your Address..." required autofocus></textarea>
                </div>
                <div class="form-group">
                    <label for="payment">Payment Method</label><br><br>
                    <input type="radio" value="Card Payment" name="payment" required><span> Card Payment</span><br><br>
                    <input type="radio" value="EMI Payment" name="payment"><span> EMI Payment</span><br><br>
                    <input type="radio" value="Net Banking" name="payment"><span> Net Banking</span><br><br>
                    <input type="radio" value="Cash on Delivery" name="payment"><span> Cash on Delivery</span><br><br>
                </div>
                <button type="submit" class="btn btn-default">Order Now</button>
            </form>
        </div>
    </div>
</div>
@endsection