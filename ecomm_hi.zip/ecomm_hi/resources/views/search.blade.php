@extends('master')
@section("content")
<!--custom-login ka style master page mai bottom mai hai 
agar dono side space hatana hai to container hata do jo custom-product se phle lgta hai-->
<div class="custom-product">
    <div class="col-sm-4">
    <a href="#">Filter</a>
    </div>
    <div class="col-sm-4">
    <!-- product below the slider-->
    <div class="trending-wrapper">
    <h2>Result for Product</h2>
        @foreach ($products as $item)
        <div class="searched-item">
        <a href="detail/{{$item['id']}}">
        <img class="trending-img" src="{{$item['gallery']}}">
            <div class="">
                <h3>{{$item['name']}}</h3>
                <h5>{{$item['description']}}</h5>

            </div>
         </a>
        </div>
     @endforeach
  </div>
  </div>
</div>

@endsection