@extends('master')
@section("content")
<!--custom-login ka style master page mai bottom mai hai 
agar dono side space hatana hai to container hata do jo custom-product se phle lgta hai-->
<div class="container">
    <div class="row">
    <div class="col-sm-6">
        <img class="detail-img" src="{{$product['gallery']}}" alt="">
     </div>
     <div class="col-sm-6">
    <a href="/" class="btn btn-danger">Go Back</a>
    <h2>Name: {{$product['name']}}</h2>
    <h3>Price: {{$product['price']}}</h3>
    <h4><u>Brand</u>: {{$product['brand']}}</h4>
    <h5><u><b>Description</b></u>: {{$product['description']}}</h5>
    <h4>MRP: {{$product['mrp']}}</h4>
    <h4>Rating: {{$product['rating']}}</h4>
    <br><br>
    <!--for adding item in cart-->
    <form action="/add_to_cart" method="POST">
    @csrf
    <input type="hidden" value="{{ $product['id']}}" name="product_id">
    <button class="btn btn-success">Add To Cart</button>
    </form>
    <button class="btn btn-primary">Buy Now</button>
    <br><br>
    </div>
        </div>

</div>

@endsection