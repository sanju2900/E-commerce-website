@extends('master')
@section("content")
<!--custom-login ka style master page mai bottom mai hai 
agar dono side space hatana hai to container hata do jo custom-product se phle lgta hai-->
<div class="custom-product">
    
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
   @foreach ($products as $item)
   <!-- slider mai ek image  active rhega -->
   <div class="item {{$item['id']==1?'active':''}}">
   <a href="detail/{{$item['id']}}">
      <img class="slider-img" src="{{$item['gallery']}}" alt="Chania">
      <div class="carousel-caption">
        <h3>{{$item['name']}}</h3>
        <p>{{$item['description']}}</p>
      </div>
      </a>
    </div>
    @endforeach
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<div>
<h1 style="color:green;"  align="center">Trending Products</h1>
<!-- product below the slider-->
<div class="trending-wrapper">
   @foreach ($products as $item)
   <div class="trending-items product-list-divider">
   <a href="detail/{{$item['id']}}" style="text-decoration: none; color: black;">
      <img class="trending-img" src="{{$item['gallery']}}">
      <div class="">
        <h3>{{$item['name']}}</h3>
        <p>{{$item['price']}}</p>
        <button type="submit" class="btn btn-primary">Learn more</button>
      </div>
      </a>
    </div>
    @endforeach
  </div>


</div>
    
</div>

@endsection