<!DOCTYPE <html>
   <html lang="en">
   <head>
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-comm project</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
   </head>

   <body>
   <!--connecting header page-->
   <?php echo View::make('header'); ?>
    
    <!--main contain of page-->
   <?php echo $__env->yieldContent('content'); ?>

    <!--footer connection-->
   <?php echo View::make('footer'); ?>
<!-- footer form se chipak rha tha to dur karne ke liye style kiye -->
     <style>
        .custom-login{
            height:500px;
            padding-top:100px
        }
        img.slider-img
        {
         height: 300px !important;
        width: 100% !important;
        object-fit: contain;
        }
        
        .custom-product 
        {
           height:600px;
        }
        .trending-img
        {
           height:200px;
        }
        .trending-items
        {
           float: left;
           width: 25%;
        }
        .trending-wrapper
        {
           margin:30px;
        }
        .detail-img
        {
           height:300px;
        }
        .search-box
        {
           width:500px !important;
        }
        .trending-image
        {
           height:200px;
        }
        .cart-list-divider
        {
           border-bottom: 1px solid #cccccc;
           margin-bottom: 20px;
           padding-bottom: 20px;
        }
        
     </style>
   </body>

</html>
<?php /**PATH D:\xampp\xampp2\htdocs\ecomm_hi\resources\views/master.blade.php ENDPATH**/ ?>