
<?php $__env->startSection("content"); ?>
<!--custom-login ka style master page mai bottom mai hai 
agar dono side space hatana hai to container hata do jo custom-product se phle lgta hai-->
<div class="custom-product">
    <div class="col-sm-4">
    <a href="#">Filter</a>
    </div>
    <div class="col-sm-4">
    <!-- product below the slider-->
    <div class="trending-wrapper">
    <h2>Result for Product</h2>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="searched-item">
        <a href="detail/<?php echo e($item['id']); ?>">
        <img class="trending-img" src="<?php echo e($item['gallery']); ?>">
            <div class="">
                <h3><?php echo e($item['name']); ?></h3>
                <h5><?php echo e($item['description']); ?></h5>

            </div>
         </a>
        </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\xampp2\htdocs\ecomm_hi\resources\views/search.blade.php ENDPATH**/ ?>