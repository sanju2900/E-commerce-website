<div class="panel panel-success">
  <div class="panel-body">
    Panel content
  </div>
  <div class="panel-footer">Panel footer</div>
</div><?php /**PATH D:\xampp\xampp2\htdocs\ecomm-en\resources\views/footer.blade.php ENDPATH**/ ?>