
<?php $__env->startSection("content"); ?>
<!--custom-login ka style master page mai bottom mai hai 
agar dono side space hatana hai to container hata do jo custom-product se phle lgta hai-->
<div class="container">
    <div class="row">
    <div class="col-sm-6">
        <img class="detail-img" src="<?php echo e($product['gallery']); ?>" alt="">
     </div>
     <div class="col-sm-6">
    <a href="/" class="btn btn-danger">Go Back</a>
    <h2>Name: <?php echo e($product['name']); ?></h2>
    <h3>Price: <?php echo e($product['price']); ?></h3>
    <h4><u>Brand</u>: <?php echo e($product['brand']); ?></h4>
    <h5><u><b>Description</b></u>: <?php echo e($product['description']); ?></h5>
    <h4>MRP: <?php echo e($product['mrp']); ?></h4>
    <h4>Rating: <?php echo e($product['rating']); ?></h4>
    <br><br>
    <!--for adding item in cart-->
    <form action="/add_to_cart" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($product['id']); ?>" name="product_id">
    <button class="btn btn-success">Add To Cart</button>
    </form>
    <button class="btn btn-primary">Buy Now</button>
    <br><br>
    </div>
        </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\xampp2\htdocs\ecomm_hi\resources\views/detail.blade.php ENDPATH**/ ?>