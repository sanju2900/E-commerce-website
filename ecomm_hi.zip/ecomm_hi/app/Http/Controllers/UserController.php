<?php

namespace App\Http\Controllers;
//to check password
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
//to check email and password is in db or not
use App\Models\User;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    //
    function login(Request $req)
    {
        $user= User::where(['email'=>$req->email])->first(); 
        if(!$user || !Hash::check($req->password,$user->password))
        {
            return "username or password is not matched";
        }
        else{
            $req->session()->put('user',$user);
            return redirect('/'); 
        }
    }

    function register(Request $req) {
        $user = new User;
        $user->name = $req->name;
        $user->email = $req->email;
        $user->address = $req->address;
        $user->password = Hash::make($req->password);
        $query = $user->save();

        if($query) {
            // return back()->with('success', 'Registration successful.!! You can now Login.');
            return redirect('/login');
        }
        else {
            return back()->with('failure', 'Oops.!! Something went wrong.');
        }    
    }

}
