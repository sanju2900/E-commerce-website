<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([
            [
                'name'=>'LG Mobile',
                'price'=>'10999',
                'brand'=>'smart phone',
                'gallery'=>'http://www.auntpeaches.com/wp-content/uploads/2015/04/fridge-682.jpg',
                'description'=>'The LG W41 Pro is powered by 2.3GHz octa-core MediaTek Helio G35 processor and it comes with 6GB of RAM. The phone packs 128GB of internal storage that can be expanded up to 512GB via a microSD card. As far as the cameras are concerned',
                'mrp'=>'till feb 2022',
                'rating'=>'4.5/5',
            ],
            [
                'name'=>'ASUS Rog',
                'price'=>'12999',
                'brand'=>'smart phone',
                'gallery'=>'https://static.toiimg.com/photo/74552749.cms',
                'description'=>'The LG W41 Pro is powered by 2.3GHz octa-core MediaTek Helio G35 processor and it comes with 6GB of RAM. The phone packs 128GB of internal storage that can be expanded up to 512GB via a microSD card. As far as the cameras are concerned',
                'mrp'=>'till jan 2022',
                'rating'=>'4.5/5',
            ],
            [
                'name'=>'oppo',
                'price'=>'8999',
                'brand'=>'smart phone',
                'gallery'=>'https://static.toiimg.com/photo/74552749.cms',
                'description'=>'The LG W41 Pro is powered by 2.3GHz octa-core MediaTek Helio G35 processor and it comes with 6GB of RAM. The phone packs 128GB of internal storage that can be expanded up to 512GB via a microSD card. As far as the cameras are concerned',
                'mrp'=>'till feb 2022',
                'rating'=>'4.5/5',
            ],
            [
                'name'=>'sumsung',
                'price'=>'19999',
                'brand'=>'smart phone',
                'gallery'=>'https://static.toiimg.com/photo/74552749.cms',
                'description'=>'The LG W41 Pro is powered by 2.3GHz octa-core MediaTek Helio G35 processor and it comes with 6GB of RAM. The phone packs 128GB of internal storage that can be expanded up to 512GB via a microSD card. As far as the cameras are concerned',
                'mrp'=>'till feb 2022',
                'rating'=>'4.5/5',
            ],

        ]);
    }
}
